int checkeod(int x) {
    if (x % 2 == 0) {
        return 0;
    } else {
        return 1;
    }
}